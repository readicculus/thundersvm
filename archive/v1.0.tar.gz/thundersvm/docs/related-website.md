Related websites to ThunderSVMs
=============
Other SVM libraries:
* [LibSVM](https://www.csie.ntu.edu.tw/~cjlin/libsvm/)
* [SVM-light](http://svmlight.joachims.org/)
* [OHD-SVM](https://github.com/OrcusCZ/OHD-SVM)
