//
// Created by shijiashuai on 1/12/17.
//
#include "thundersvm/thundersvm.h"

INITIALIZE_EASYLOGGINGPP
